import math

def calculateDistance(row, neighbor, attr, df):
    # In this case the higher the distance value, the more similar the
    # tuple is. Every time an attribute is equal, add one to the distance.

    distance = 0
    
    for column in df.columns:
        if (column == attr):
            continue
        if (row[column] == neighbor[column]):
            distance = distance + 1
    return distance




def calcLowestDistance(distances):
    # Try to find the minimum distance given the distances array that holds
    # the k most similar tuples to the one we are trying to classify

    # variable to hold the value of minimum distance
    minDis = distances[0]
    # location in the array of the minimum distance
    loc = 0
    # loop through to find the minimum distance
    for i in range(1, len(distances)):
        if (minDis > distances[i]):
            minDis = distances[i]
            loc = i
    return minDis, loc



def maxVotes(votes):
    maxVote = 0
    maxKey = ""
    for keys in votes.keys():
        if(votes[keys] > maxVote):
            maxVote = votes[keys]
            maxKey = keys
    return maxKey



def kNN(df, classAttr, predictClass):
    # print("What attribute would you like to classify on?")
    # attribute = input()

    # print("How many neighbors would you like to help make the classification?")
    k = int(math.sqrt(len(df)))
    # print(k)

    # tuple that we want to classify, in the case of this method it will be poisonous or edible
    needsClass = predictClass

    # array to hold the k nearest (most similar) tuples
    similarTuples = []

    # array of distances that corresponds to the k nearest tuples
    distance = []
    for i in range(int(k)):
        distance.append(0)

    # variable used to compare lowest distances
    lowestDistance = 0

    # for loop to assign tuples to the k nearest tuples (similarTuples)
    # and to update distances array
    for rowNum in range(0, len(df)):

        # variable to store the current tuple we are looking at
        row = df.iloc[rowNum]

        # if similarTuples array is not full yet (we don't have k of them) then append
        # to the array to fill it up
        if (len(similarTuples) < int(k)):
            similarTuples.append(row)
            distance[len(similarTuples) - 1] = calculateDistance(needsClass, row, classAttr, df)
            continue

        # variable to store the current tuples distance from the one we are trying to classify
        curRowDistance = calculateDistance(needsClass, row, classAttr, df)

        # variable to store the lowest distance of all the similarTuples
        lowestDistance, x = calcLowestDistance(distance)

        # if the current distance is higher than the lowest distance in similarTuples, then replace
        # that tuple with the current row
        if (curRowDistance > lowestDistance):
            distance[x] = curRowDistance
            similarTuples[x] = row

    return similarTuples


class KNN_Classifier:
    def __init__(self, df, classLabel):
        self.dataframe = df
        self.classLabel = classLabel
        self.simTuples = []

    def fit(self, X, y):
        self.simTuples = kNN(X, self.classLabel, y)
        return

    def predict(self):

        votes = {}
        for tuples in self.simTuples:
            attr = tuples[self.classLabel]
            if attr in votes:
                votes[attr] += 1
            else:
                votes[attr] = 1

        return maxVotes(votes)

    def clear(self):
        self.simTuples = []
